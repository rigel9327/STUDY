package com.rigel.menu;

public enum 음료 {
	아메리카노,
	라떼,
	카푸치노,
	스무디,
	쥬스,
	티
}
