package com.rigel.menu;

public enum BeverTakeOut {
	HERE,
	TAKEOUT
}
