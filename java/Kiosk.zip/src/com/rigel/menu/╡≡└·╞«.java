package com.rigel.menu;

public enum 디저트 {
	쿠키,
	빵,
	샐러드,
	피자,
}
