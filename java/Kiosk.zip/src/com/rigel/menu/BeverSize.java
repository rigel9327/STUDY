package com.rigel.menu;

public enum BeverSize {
	SMALL,
	MEDIUM,
	LARGE
}
