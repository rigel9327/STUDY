package com.rigel.menu;

public enum BeverShot {
	ONE_SHOT,
	TWO_SHOT
}