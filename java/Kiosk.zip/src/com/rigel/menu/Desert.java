package com.rigel.menu;

public enum Desert {
    COOKIE,
    BREAD,
    SALAD,
    PIZZA,
}