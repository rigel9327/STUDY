package com.rigel.menu;

//enum으로 서로 연관된 상수들의 집합 작성

public enum Beverage {
    AMERICANO,
    LATTE,
    CAPPUCCINO,
    SMOOTHE,
    JUICE,
    TEA,
}