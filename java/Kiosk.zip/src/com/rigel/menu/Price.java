package com.rigel.menu;

public class Price {
	private final int PRICE01 = 2500;
	private final int PRICE02 = 3500;
	private final int PRICE03 = 3500;
	private final int PRICE04 = 4000;
	private final int PRICE05 = 4000;
	private final int PRICE06 = 2500;
	private final int PRICE07 = 2500;
	private final int PRICE08 = 4500;
	private final int PRICE09 = 7500;
	private final int PRICE010 = 8500;
	public int[] getBeveragePrice() {
		int[] priceArray = { PRICE01, PRICE02, PRICE03, PRICE04, PRICE05, PRICE06 };
		return priceArray;
	}

	public int[] getDesertPrice() {
		int[] priceArray = { PRICE07, PRICE08, PRICE09, PRICE010 };
		return priceArray;
	}
}
