package com.rigel.menu;

public enum BeverTemp {
	ICE,
	HOT
}
