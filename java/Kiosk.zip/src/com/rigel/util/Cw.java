package com.rigel.util;

	public class Cw {
		public static void t(String s) {
			System.out.print(s);
		}
		public static void ln(String s) {
			System.out.println(s);
		}
		public static void f(String s) {
			System.out.printf(s);
		}
	}


