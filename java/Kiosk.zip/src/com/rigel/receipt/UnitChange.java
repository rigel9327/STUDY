package com.rigel.receipt;

import com.rigel.menu.*;

public class UnitChange {
	
	//int -> 요청사항(String)으로 변경
	public static String toString_bever(int i) {
		return 음료.values()[--i].toString();
	}
	
	public static String toString_desert(int i) {
		return 디저트.values()[--i].toString();
	}
	
	public static String toString_temp(int i) {
		if(i == 0){
			return "";
		}
		return BeverTemp.values()[--i].toString();
	}
	
	public static String toString_shot(int i) {
		if(i == 0){
			return "";
		}
		else if(BeverShot.values()[--i].toString().equals(BeverShot.ONE_SHOT.toString())) {
			return "1샷";
		}
		return "2샷";
	}
	
	public static String toString_size(int i) {
		return BeverSize.values()[--i].toString();
	}
	
	public static String toString_takeout(int i) {
		if(BeverTakeOut.values()[--i].toString().equals(BeverTakeOut.HERE.toString())) {
			return "매장이용";
		}
		return "테이크아웃";
	}

	/*------------------------------------------*/
	//int -> 금액(int)으로 변경
	public int toMoney_bever(int i){
		Price p = new Price();
		return p.getBeveragePrice()[i-1];
	}
	public int toMoney_desert(int i){
		Price pp = new Price();
		return pp.getDesertPrice()[i-1];
	}
	public int toMoney_temp(int i){
		return 0;
	}
	public int toMoney_shot(int i){
		int money = 0;
		if(i == 2){
			money = 500;
		}
		return money;
	}
	public int toMoney_size(int i){
		return 500*--i;
	}
	public int toMoney_takeout(int i){
		int money = 0;
		if(i==1){
			money = 500;
		}
		return money;
	}
}