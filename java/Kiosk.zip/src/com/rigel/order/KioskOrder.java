package com.rigel.order;

import com.rigel.order.OrderCollect;
import com.rigel.menu.Beverage;
import com.rigel.menu.Desert;
import com.rigel.menu.Price;
import com.rigel.menu.음료;
import com.rigel.menu.디저트;
import com.rigel.kiosk.*;
import com.rigel.receipt.PrintReceipt;

import java.util.Scanner;

public class KioskOrder {

	boolean wantToCancel = false; // 주문취소 여부
	boolean orderMore = true; // 추가주문 여부
	boolean orderCheck = true; // 주문확인 결과

	// constructor. 생성과 동시에 start() 메서드 호출
	protected KioskOrder() {
		Disp.title();
		start();
	}

	// 주문받고(receiveOrder) 영수증을 출력(PrintReceipt)하는 메서드 호출
	private void start() {

		wantToCancel = false;
		orderMore = true;
		orderCheck = true;
		int count = 0;

		// 추가주문 여부
		while (orderMore) {
			wantToCancel = false;
			boolean[] boolArr = receiveOrder();
			orderMore = boolArr[0];

			// 주문개수 증가
			if (!boolArr[1]) {
				count++;
				System.out.println("count++");
			}
		}
		// 주문확인 결과
		if (orderCheck) {
			new PrintReceipt(count);
		} else {
			orderMore = true;
			orderCheck = true;
			this.start();
		}
	}

	// Reaction 인터페이스 구현객체를 호출하여 주문받기
	private boolean[] receiveOrder() {
		Scanner scan = new Scanner(System.in);

		boolean[] booleans = new boolean[2];
		while (!wantToCancel) {
			printMenu();
			Reaction oper = null;

			// 음료 종류
			oper = new Input_beverage();
			wantToCancel = oper.execute(scan);
			if (wantToCancel) {
				reset();
				break;
			}

			// 음료 온도
			oper = new Input_temp();
			wantToCancel = oper.execute(scan);
			if (wantToCancel) {
				reset();
				break;
			}

			// 음료 샷
			oper = new Input_shot();
			wantToCancel = oper.execute(scan);
			if (wantToCancel) {
				reset();
				break;
			}

			// 음료 크기
			oper = new Input_size();
			wantToCancel = oper.execute(scan);
			if (wantToCancel) {
				reset();
				break;
			}

			// 테이크아웃
			oper = new Input_takeout();
			wantToCancel = oper.execute(scan);
			if (wantToCancel) {
				reset();
				break;
			}

			oper = new Input_more();
			orderMore = oper.execute(scan);

			// 추가주문x
			if (!orderMore) {
				oper = new Input_check();
				orderCheck = oper.execute(scan);
				break;
			}
			
			// 음료 종류
//			oper = new Input_desert();
//			wantToCancel = oper.execute(scan);
//			if (wantToCancel) {
//				reset();
//				break;
		}
		booleans[0] = orderMore;
		booleans[1] = wantToCancel;
		return booleans;
	}


	// 주문취소시 List를 null로 만듬
	private void reset() {
		System.out.println("주문 취소");
		OrderCollect col = OrderCollect.getInstance();
		col.reset_orderInfo();
	}

	// 메뉴 출력
	private void printMenu() {
		음료[] 음료배열 = 음료.values();
		Price p = new Price();
		int[] priceArr = p.getBeveragePrice();

		디저트[] 디저트배열 = 디저트.values();
		Price pp = new Price();
		int[] priceArr2 = p.getDesertPrice();

		System.out.println("------------------------------");
		System.out.println("******* HONEST COFFEE  *******");
		System.out.println("------------------------------");
		System.out.println("-------------   --------------");
		System.out.println("--  1.음료  --   --  2.디저트  --");
		System.out.println("-------------   --------------");
		System.out.println("-------------   --------------");
		System.out.println("------------------------------");
		System.out.println("-주문할 품목을 선택해주세요.(1 or 2)-");

		Scanner sel = new Scanner(System.in);
		String input = sel.next();
		if (input.equals("1")) {
			System.out.println("***********  메뉴  ***********");
			System.out.println("------------ 음료 -------------");
			for (int i = 0; i < Beverage.values().length; i++) {
				System.out.printf(" %d. %s\t\t%d원\n", i + 1, 음료배열[i], priceArr[i]);
				System.out.println("------------------------------");
			}
		} else {
//			System.out.println("------------ 디저트 -------------");
//			for (int i = 0; i < Desert.values().length; i++) {
//				System.out.printf(" %d. %s\t\t%d원\n", i + 1, 디저트배열[i], priceArr2[i]);
//				System.out.println("------------------------------");
			}
		}
	}
