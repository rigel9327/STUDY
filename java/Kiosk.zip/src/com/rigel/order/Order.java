package com.rigel.order;

public class Order {
    private int beverage;		//음료 종류
    private int beverTemp;	    //음료 온도
    private int beverSize;		//음료 크기
    private int beverShot;		//음료 샷추가
    private int beverTakeOut;   //음료 테이크아웃
    private int desert;         //디저트 종류

    public int getBeverage() {
        return beverage;
    }
    
    public Order setBeverage(int beverage) {
        this.beverage = beverage;
        return this;
    }

    public int getBeverTemp() {
        return beverTemp;
    }
    
    public Order setBeverTemp(int beverTemp) {
        this.beverTemp = beverTemp;
        return this;
    }
    public int getBeverSize() {
    	return beverSize;
    }
    public Order setBeverSize(int beverSize) {
    	this.beverSize = beverSize;
    	return this;
    }

    public int getBeverShot() {
        return beverShot;
    }
    
    public Order setBeverShot(int beverShot) {
        this.beverShot = beverShot;
        return this;
    }

    public int getBeverTakeOut() {
        return beverTakeOut;
    }
    
    public Order setBeverTakeOut(int beverTakeOut) {
        this.beverTakeOut = beverTakeOut;
        return this;
    }
    
    public int getDesert() {
        return desert;
    }
    
    public Order setDesert(int desert) {
        this.desert = desert;
        return this;
    }
}