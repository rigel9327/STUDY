package com.rigel.order;

import java.util.ArrayList;
import java.util.List;

public class OrderCollect {
	/*
	 * singleton 으로 구성
	 * -OrderCollection(클래스)
	 * -orderList(List)
	 * -order(Orders)
	 */
    private static OrderCollect orderSpec = null;
    private static List<Order> orderList = null;
    private static Order order = null;
    
    private OrderCollect(){	}

    public static OrderCollect getInstance(){
        if(orderSpec == null){
        	orderSpec = new OrderCollect();
        }
        return orderSpec;
    }

    public static List<Order> get_orderList(){
        if(orderList == null){
        	orderList = new ArrayList<>();
        }
        return orderList;
    }
    
    public static Order get_orderData() {
    	if(order == null) {
    		order = new Order();
    	}
    	return order;
    }
    
	private void resetData(){
		orderList = null;
	}

    //List에 데이터 추가하기
	public List<Order> add_orderInfo(Order data) {
		orderList = get_orderList();		
		
		Order orderData = new Order();
		orderData.setBeverage(data.getBeverage())
				 .setBeverTemp(data.getBeverTemp())
				 .setBeverShot(data.getBeverShot())
				 .setBeverSize(data.getBeverSize())
				 .setBeverTakeOut(data.getBeverTakeOut())
				 .setDesert(data.getDesert());
		
		orderList.add(orderData);
		
		return orderList;
	}

	//List에 담긴 정보 초기화
	public void reset_orderInfo() {
		resetData();
	}
}