package com.rigel.kiosk;
import java.util.Scanner;
import com.rigel.order.Order;
import com.rigel.order.OrderCollect;
import com.rigel.receipt.UnitChange;
import com.rigel.menu.BeverSize;
public class Input_size implements Reaction {
	 @Override
	    public boolean execute(Scanner scan) {
	    	int input	 		= 0;		//주문내역 저장
	        boolean goToNext 	= false;	//반복 플래그 변수
	        boolean wantToCancel = false;	//리턴 객체
			Order order = OrderCollect.get_orderData();
	 	
	        while(!goToNext) {
	    	
				Script m = new Script();
		    	System.out.print(m.getScript2_size());
		    	String request = scan.next().trim().toLowerCase();  
	      		boolean isNumber = CheckRequest.isNumber(request);
	      		
	            if(isNumber){
	              	int num = Integer.parseInt(request);
	                int count = BeverSize.values().length;
	                
	                if(0<num && num<count+1) {
	                	input = num;

	                	int bever = order.getBeverage();
	                	int temp = order.getBeverTemp();
	                	int shot = order.getBeverShot();
	                	String str1 = UnitChange.toString_bever(bever);
	                	String str2 = UnitChange.toString_temp(temp);
	                	String str3 = UnitChange.toString_size(num);
	                	String str4 = UnitChange.toString_shot(shot);

						//출력양식 조정 (커피<->음료)
	                	if(bever==1 || bever==2){
							System.out.printf("%s(%s/%s/%s)\n", str1, str2, str3, str4);
						} else{
							System.out.printf("%s(%s)\n", str1, str4);
						}

	            		goToNext = true;
	            	} else {
	            		System.out.println("번호를 다시 입력바랍니다 (1~3)");
	            	}         
	            }
	            else if(request.equals("c")) {
	            	System.out.println(m.getScript6_cancel());
	            	
	            	request = scan.next().trim().toLowerCase();
	            	boolean isYesOrNo = CheckRequest.isYesOrNo(request);
	            	
	            	if(isYesOrNo && request.equals("y")) {
						System.out.println(m.getScript7_again());
	                	wantToCancel = true;
	                	break;
	            	}
	            }        
	            else {
					System.out.println(m.getScript8_numberOnly());
	            }
	    	}
	        order.setBeverSize(input);
	        
			return wantToCancel;
	    }
	}

