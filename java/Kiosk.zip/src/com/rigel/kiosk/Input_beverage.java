package com.rigel.kiosk;
import com.rigel.util.Cw;
import java.util.Scanner;
import com.rigel.order.Order;
import com.rigel.order.OrderCollect;
import com.rigel.receipt.UnitChange;
import com.rigel.menu.Beverage;
//음료 종류를 입력받는 역할 수행
public class Input_beverage implements Reaction {
  @Override
  public boolean execute(Scanner scan) {
      int input	 		= 0;		//주문내역 저장
      boolean goToNext 	= false;	//반복 플래그 변수
      boolean wantToCancel = false;	//리턴 객체
      //입력 반복문
      while(!goToNext) {
  	
	        //멘트 출력 및 입력값 받기
			Script m = new Script();
	    	Cw.t(m.getScript0_choose());
	    	String request = scan.next().trim().toLowerCase();
	    	//입력값이 숫자인지 확인
    		boolean isNumber = CheckRequest.isNumber(request);
    		
          if(isNumber){
            	int num = Integer.parseInt(request);
              int count = Beverage.values().length;
              
              //숫자가 범위에 해당하는지 확인
              if(0<num && num<count+1) {
              	input = num;

              	//요청사항 출력하기
              	String str1 = UnitChange.toString_bever(num);
              	System.out.printf("%s\n", str1);       
              	
          		goToNext = true;
          	} else {
          		System.out.println("번호를 다시 입력바랍니다 (1~6)");
          	}         
          }
          //취소시
          else if(request.equals("c")) {
          	Cw.ln(m.getScript6_cancel());
          	
          	//yes no 입력 확인
          	request = scan.next().trim().toLowerCase();
          	boolean isYesOrNo = CheckRequest.isYesOrNo(request);
          	
          	if(isYesOrNo && request.equals("y")) {
					System.out.println(m.getScript7_again());
              	wantToCancel = true;
              	break;
          	}
          }        
          else {
				Cw.ln(m.getScript8_numberOnly());
          }
  	}
      //요청사항 반영
      Order order = OrderCollect.get_orderData();
      order.setBeverage(input);
  	
  	return wantToCancel;
  }    
}