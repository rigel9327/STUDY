package com.rigel.kiosk;

import com.rigel.order.KioskOrder;

public class KioskOn extends KioskOrder {

	//부모 클래스 생성자 호출
	public KioskOn() {
		super();
	}

	public static void main(String[] args) {
		new KioskOn();
	}
}
