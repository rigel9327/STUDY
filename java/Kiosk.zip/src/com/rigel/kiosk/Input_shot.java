package com.rigel.kiosk;
import java.util.Scanner;
import com.rigel.order.Order;
import com.rigel.order.OrderCollect;
import com.rigel.receipt.UnitChange;
import com.rigel.menu.BeverShot;
public class Input_shot implements Reaction {
	@Override
	public boolean execute(Scanner scan) {
        int input	 		= 0;		//주문내역 저장
        boolean goToNext 	= false;	//반복 플래그 변수
        boolean wantToCancel = false;	//리턴 객체

		//커피 종류를 주문하지 않았다면 아래 while 문 실행되지 않음
		Order order = OrderCollect.get_orderData();
		if(!(order.getBeverage()==1 || order.getBeverage()==2)){
			goToNext = true;
		}
   	
        while(!goToNext) {    	
			Script m = new Script();
			System.out.print(m.getScript3_shot());
	    	String request = scan.next().trim().toLowerCase();  
      		boolean isNumber = CheckRequest.isNumber(request);
      		
            if(isNumber){
              	int num = Integer.parseInt(request);
                int count = BeverShot.values().length;
                
                if(0<num && num<count+1) {
                	input = num;
                	
                	int bever = order.getBeverage();
                	int temp = order.getBeverTemp();
                	String str1 = UnitChange.toString_bever(bever);
                	String str2 = UnitChange.toString_temp(temp);
                	String str3 = UnitChange.toString_shot(num);
                	
                	System.out.printf("%s(%s/%s)\n", str1, str2, str3);
                	
            		goToNext = true;
            	} else {
            		System.out.println("번호를 다시 입력바랍니다 (1~2)");
            	}         
            }
            else if(request.equals("c")) {
            	System.out.println(m.getScript6_cancel());
            	
            	request = scan.next().trim().toLowerCase();
            	boolean isYesOrNo = CheckRequest.isYesOrNo(request);
            	
            	if(isYesOrNo && request.equals("y")) {
					System.out.println(m.getScript7_again());
                	wantToCancel = true;
                	break;
            	}
            }        
            else {
				System.out.println(m.getScript8_numberOnly());
            }
    	}
        order.setBeverShot(input);

		return wantToCancel;
	
}

}
