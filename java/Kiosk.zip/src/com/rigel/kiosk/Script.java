package com.rigel.kiosk;

public class Script {
    private final String SCRIPT0_CHOOSE		 = "\n음료(번호)를 선택해주세요 (주문취소 c): ";
    private final String SCRIPT1_TEMP		 = "\n1.ice 2.hot 선택 (주문취소 c): ";
    private final String SCRIPT2_SIZE	 	 = "\n1.SMALL(+0원) 2.MEDIUM(+500원) 3.LARGE(+1000원) 선택 (주문취소 c): ";
    private final String SCRIPT3_SHOT 		 = "\n1.1샷(+0원) 2.2샷(+500원) 선택 (주문취소 c): ";
    private final String SCRIPT4_TAKEOUT	 = "\n1.매장이용(+500원) 2.테이크아웃(+0원) 선택 (주문취소 c): ";
    private final String SCRIPT5_MORE  = "\n추가주문 하시겠습니까? (y/n): ";
    private final String SCRIPT6_CANCEL		 = "\n주문을 취소하시겠습니까? (y/n): ";
	private final String SCRIPT7_AGAIN = "주문이 취소되었습니다. 다시 입력해주세요";
	private final String SCRIPT8_NUMBER_ONLY = "숫자를 입력바랍니다";
	private final String SCRIPT9_YESNO_ONLY	 = "y 혹은 n을 입력바랍니다";
	private final String SCRIPT10_CHOOSE_DESERT	 = "디저트(번호)를 선택해주세요 (주문취소 c):";

    public String getScript0_choose() {
    	return SCRIPT0_CHOOSE; 
    	}
	public String getScript1_temp() {
		return SCRIPT1_TEMP;
	}
	public String getScript2_size() {
		return SCRIPT2_SIZE;
	}
	public String getScript3_shot() {
		return SCRIPT3_SHOT;
	}
	public String getScript4_takeout() {
		return SCRIPT4_TAKEOUT;
	}
	public String getScript5_more() {
		return SCRIPT5_MORE;
	}
	public String getScript6_cancel() {
		return SCRIPT6_CANCEL;
	}
	public String getScript7_again(){ return SCRIPT7_AGAIN; }
	public String getScript8_numberOnly() { return SCRIPT8_NUMBER_ONLY; }
	public String getScript9_yesno_only() { return SCRIPT9_YESNO_ONLY; }
	public String getScript10_choose_desert() {
		return SCRIPT10_CHOOSE_DESERT;
	}
}

