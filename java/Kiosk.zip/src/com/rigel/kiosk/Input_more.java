package com.rigel.kiosk;
import java.util.Scanner;
import com.rigel.order.Order;
import com.rigel.order.OrderCollect;
public class Input_more implements Reaction{
	@Override
	public boolean execute(Scanner scan) {
		String request 		= "";		//입력 버튼
		boolean goToNext 	= false;	//반복 플래그 변수
		boolean orderMore	= false;	//추가 주문 여부 리턴

		//OrderCollection 클래스의 인스턴스 호출
		//-> add_orderInfo() 메서드 호출
		//-> 요청사항 리스트에 삽입하기
		Order data = OrderCollect.get_orderData();
		OrderCollect spec = OrderCollect.getInstance();
		spec.add_orderInfo(data);

		//추가주문 여부를 받기위한 반복문
    	while(!goToNext) {
    		Script m = new Script();
        	System.out.print(m.getScript5_more());
        	request = scan.next().trim().toLowerCase();    	
    		
        	//y or n 입력 확인
        	boolean isYesOrNo = CheckRequest.isYesOrNo(request);
	        if(isYesOrNo){
	        	if(request.equals("y")) {
	        		orderMore = true;
	        	}
	        	goToNext = true;
	        } else {
	        	System.out.println("y 혹은 n을 입력바랍니다");
	        }
    	}
		return orderMore;
	}
}